import React, { useCallback, useEffect, useState } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import { Module } from './Module'
import { Theme } from './Theme'
import { Course } from './Course'
import { api, courseRequest, moduleRequest } from '../../../../shared/request'
import { useDispatch, useSelector } from 'react-redux'
import { AppStateType } from '../../../../store/store'
import { fetchDataById } from '../../../../store/actions/shared'
import { userActions } from '../../../../store/actions/user'
import { Loader } from '../../../components/utils/Loader'

export default () => {


    const {id} = useParams()
    const history = useHistory()
    const location = history.location.pathname
    const themeId = location.split('/')[3]
    const dispatch = useDispatch()
    const [load, setLoad] = useState(true)
    const [localCourse, setLocalCourse] = useState<any>()
    const [localTheme, setLocalTheme] = useState<any>()
    const [localModule, setLocalModule] = useState<any>()
    const {courses, loading} = useSelector((s: AppStateType) => s.shared)
    const {course, module, theme} = useSelector((s: AppStateType) => s.user)

    const choseItems = useCallback((data: any) => {
        dispatch(userActions.choseItem({...data}))
    }, [dispatch])

    const fetchModule = useCallback(async (id) => {
        if (!module) {
            if (!course) {
                setLocalModule(await dispatch(fetchDataById(moduleRequest, id)))
            } else {

                setLocalModule(course?.modules?.find(c => c.id === parseInt(id)))
            }
        }
        setLoad(false)
    }, [course, dispatch, module])

    const choseModules = useCallback(async (id) => {
        await fetchModule(id)
        choseItems(module)
    }, [fetchModule, choseItems])

    const fetchCourse = useCallback(async (id) => {
        if (!course) {
            if (!courses.length) {
                const course = await dispatch(fetchDataById(courseRequest, id))
                setLocalCourse(course)
            } else {
                setLocalCourse(courses.find(c => c.id === parseInt(id)))
            }
        }
    }, [course, courses, dispatch])


    const fetchTheme = useCallback(async (id) => {
        if (!theme) {
            if (id) {
                const splits = id.split('-')
                setLocalTheme(await dispatch(fetchDataById(`${ api }/${ splits[1] }`, id)))
            }
        }
    }, [theme, dispatch])

    useEffect(() => {
        fetchCourse(id)
        setLoad(false)
    }, [fetchCourse, id])

    useEffect(() => {
        fetchTheme(themeId)
        setLoad(false)
    }, [fetchTheme, themeId])

    console.log(loading, load, course, localCourse, module)
    // useEffect(() => {
    //     const themeFetch = async () => {
    //         if (themeId) {
    //             const splits = themeId.split('-')
    //
    //             const result = await request(`${ api }/${ splits[1] }result/${ splits[0] }`)
    //             let response
    //             if (!theme) {
    //                 response = await request(`${ api }/${ splits[1] }/${ splits[0] }`)
    //
    //             }
    //             const theme1: any = {theme: {...response ?? theme, receivedPoints: result?.points ?? 0}}
    //             splits[1] === 'codeTask' && result?.usersCode
    //                 ? theme1.theme.initailCode = result.usersCode
    //                 : splits[1] === 'testTask' && result?.answers ? theme1.theme.questions = result.answers : theme1.checked = true
    //             chooseTheme(theme1)
    //         }
    //     }
    //     const timeout = setTimeout(() => themeFetch(), 400)
    //     return () => {
    //         clearTimeout(timeout)
    //     }
    //     // eslint-disable-next-line
    // }, [themeId])
    return (
        <main className="page">
            <div className="container">
                <div className="row">
                    { loading || load ? <Loader/> : localModule || module ?
                        <Module module={ localModule || module }
                                onChooseTheme={ choseItems }/> :

                        localCourse && <Course loading={ loading || load } course={ localCourse }
                                               onChooseModule={ choseModules }/> }
                    <div className="col-md-8 col-xs-12">
                        <div className="container">
                            <Theme loading={ loading || load } theme={ theme ?? localTheme }
                                   nextThema={ choseItems }/>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}
