﻿namespace UlearnServices.Models.Tasks.CodeTasks
{
    public class CodeTaskForReviewDto
    {
        public string Text { get; set; }
    }
}