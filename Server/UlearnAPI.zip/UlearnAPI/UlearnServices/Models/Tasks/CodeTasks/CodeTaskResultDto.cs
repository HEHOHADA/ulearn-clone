﻿namespace UlearnServices.Models.Tasks.CodeTasks
{
    public class CodeTaskResultDto
    {
        public int CodeTaskId { get; set; }
        public string Code { get; set; }
    }
}