﻿namespace UlearnServices.Models.Tasks.CodeTasks
{
    public class CodeTaskResultPartialDto
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Task { get; set; }
        public int Points { get; set; }
    }
}