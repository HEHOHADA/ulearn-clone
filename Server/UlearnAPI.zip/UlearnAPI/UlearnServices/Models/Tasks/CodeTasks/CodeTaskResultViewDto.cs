﻿namespace UlearnServices.Models.Tasks.CodeTasks
{
    public class CodeTaskResultViewDto
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Code { get; set; }
        public int Points { get; set; }
    }
}