﻿namespace UlearnServices.Models.Tasks.VideoTasks
{
    public class VideoTaskResultDto
    {
        public int VideoTaskId { get; set; }
    }
}