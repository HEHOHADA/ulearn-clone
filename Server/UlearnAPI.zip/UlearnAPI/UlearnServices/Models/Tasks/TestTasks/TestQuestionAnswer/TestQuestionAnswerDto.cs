﻿namespace UlearnServices.Models.Tasks.TestTasks.TestQuestionAnswer
{
    public class TestQuestionAnswerDto
    {
        public string Text { get; set; }
        public bool IsRight { get; set; }
    }
}