﻿namespace UlearnServices.Models.Course
{
    public class CourseDto
    {
        public int SubscriptionId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}