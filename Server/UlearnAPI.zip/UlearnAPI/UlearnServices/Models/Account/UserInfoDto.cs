﻿namespace UlearnServices.Models.Account
{
    public class UserInfoDto
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
    }
}