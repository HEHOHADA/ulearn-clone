﻿namespace UlearnServices.Models.Module
{
    public class ModuleDto
    {
        public int CourseId { get; set; }
        public string Name { get; set; }
    }
}