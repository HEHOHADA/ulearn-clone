﻿namespace UlearnServices.Models.Subscription
{
    public enum SortType
    {
        PriceDescending,
        PriceAscending,
        LevelDescending,
        LevelAscending
    }
}