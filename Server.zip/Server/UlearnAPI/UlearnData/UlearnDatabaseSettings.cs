﻿namespace UlearnData
{
    public class UlearnDatabaseSettings
    { 
        public string LogsCollectionName { get; set; }
        public string MessagesCollectionName { get; set; }
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
    }
}